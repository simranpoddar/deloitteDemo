$( document ).ready(function() {
	$( "#load_more" ).click(function() {
		$(this).hide();
	$( "#last" ).slideDown("slow");
	});
});
